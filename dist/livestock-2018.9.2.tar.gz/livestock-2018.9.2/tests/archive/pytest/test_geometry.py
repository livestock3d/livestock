
def test_obj_to_shapefile():
    # TO DO
    pass
