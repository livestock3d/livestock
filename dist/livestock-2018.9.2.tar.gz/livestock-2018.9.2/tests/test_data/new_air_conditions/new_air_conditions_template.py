# Imports
import livestock.air as la
# Run function
if __name__ == '__main__':
	la.new_temperature_and_relative_humidity(r'C:\Users\Christian\Dropbox\Uddannelse\DTU\Projekter\Speciale\Wardi\Wardi_No_Water_v3/NewAir')
# Announce that template finished and create out file
print('Finished with template')