import win_cmf as wc

wc.surface_flux_results(r'C:\Users\Christian\Desktop\Livestock\CMF_Surface_Flux')