import geometry as geo

obj = r'C:\Users\Christian\Dropbox\Arbejde\DTU BYG\Livestock\livestock\livestock\test\test_data\obj_to_shp\mesh.obj'
shp = r'C:\Users\Christian\Dropbox\Arbejde\DTU BYG\Livestock\livestock\livestock\test\test_data\obj_to_shp\shape_mesh.shp'

geo.obj_to_shp(obj, shp)
