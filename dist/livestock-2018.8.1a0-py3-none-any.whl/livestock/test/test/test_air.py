import air as air
import shutil



folder_path = r'C:\Users\Christian\Dropbox\Arbejde\DTU BYG\Livestock\livestock\livestock\test\test_data\new_air_conditions'

if __name__ == '__main__':
    air.new_temperature_and_relative_humidity(folder_path)
