import win_cmf as wc

wc.cell_results('surface_water_flux',
                r'C:\Users\Christian\Desktop\Livestock\CMF_Slope\results.xml',
                r'C:\Users\Christian\Desktop\Livestock\CMF_Slope')